package com.cts.AdminLoginSecurity.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import java.util.*;
@RestController
public class HomeController {
	/*@RequestMapping(value="/admin",method=RequestMethod.GET,produces = "application/json")
	public String getAdmin1()
	{
		
		//mdv.addAttribute("Greetings", msg1);
		return  "\"My Login is sucess\"" ;
	}
*/

   @RequestMapping(value="/admin/{name}/{password}",method=RequestMethod.GET,produces = "application/json")
	public String getAdmin(@PathVariable("name") String name,@PathVariable("password") String password)
	{
		
		//mdv.addAttribute("Greetings", msg1);
		return  "\"My Login is sucess\"" ;
	}



}